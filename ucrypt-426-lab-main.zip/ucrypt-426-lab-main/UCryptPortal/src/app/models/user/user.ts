export interface User {
  userName: string;
  role: string;
}
