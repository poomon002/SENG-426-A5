export interface RegisterRequest {
    name: string,
    password: string;
    email: string;
    role: string
}
