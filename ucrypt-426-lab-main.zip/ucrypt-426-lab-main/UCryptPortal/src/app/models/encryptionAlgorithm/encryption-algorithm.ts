export interface EncryptionAlgorithm {
  id: number;
  name: string;
  displayName: string;
}
