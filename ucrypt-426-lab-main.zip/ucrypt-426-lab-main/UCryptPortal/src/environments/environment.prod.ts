export const environment = {
  production: true,
  apiDomain: '20.108.185.182:8888',
  apiBaseUrl: 'http://20.108.185.182:8888/',
  apiUrl: 'http://20.108.185.182:8888/ucrypt/api/v1/',
};
